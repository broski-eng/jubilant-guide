/* ================= MULTIPLAYER (auto-injected) ================= */
const MP={on:false,host:false,id:null,ws:null,peers:new Map(),pT:0,enT:0,
 url:new URLSearchParams(location.search).get('server')||((location.protocol==='https:'?'wss://':'ws://')+location.host),
 connect(){
  if(this.ws||location.protocol==='file:')return;
  try{this.ws=new WebSocket(this.url)}catch(e){return}
  this.ws.onopen=()=>{this.on=true;this.join()};
  this.ws.onclose=()=>{this.on=false;this.ws=null;this.host=false;this.clearPeers();setTimeout(()=>this.connect(),3000)};
  this.ws.onmessage=e=>{try{this.recv(JSON.parse(e.data))}catch(err){console.error('[MP]',err)}}},
 send(m){if(this.on&&this.ws&&this.ws.readyState===1)this.ws.send(JSON.stringify(m))},
 join(){if(this.on&&!S.title)this.send({t:'join',w:S.world,i:S.isle,name:'P'+Math.floor(Math.random()*900+100)})},
 clearPeers(){for(const p of this.peers.values())scene.remove(p.m);this.peers.clear();this.hudN()},
 hudN(){$('hint').innerHTML=(this.on?'ONLINE · '+(this.peers.size+1)+'&nbsp;&nbsp;&nbsp;':'')+'M · SOUND&nbsp;&nbsp;&nbsp;ESC · PAUSE'},
 addPeer(p){
  if(this.peers.has(p.id))return;
  const col=new THREE.Color().setHSL((p.id*.137)%1,.65,.55),g=new THREE.Group();
  const mat=new THREE.MeshLambertMaterial({color:col}),skin=new THREE.MeshLambertMaterial({color:0xe8c9a0});
  const body=new THREE.Mesh(new THREE.BoxGeometry(.6,.9,.35),mat);body.position.y=.75;
  const head=new THREE.Mesh(new THREE.BoxGeometry(.5,.5,.5),skin);head.position.y=1.45;
  const nose=new THREE.Mesh(new THREE.BoxGeometry(.12,.12,.1),mat);nose.position.set(0,1.42,-.3);
  const legs=new THREE.Mesh(new THREE.BoxGeometry(.5,.5,.3),new THREE.MeshLambertMaterial({color:0x33364a}));legs.position.y=.25;
  g.add(body,head,nose,legs);scene.add(g);
  this.peers.set(p.id,{m:g,x:p.x||0,y:p.y||0,z:p.z||0,yaw:p.yaw||0,tx:p.x||0,ty:p.y||0,tz:p.z||0,tyaw:p.yaw||0});
  this.hudN()},
 delPeer(id){const p=this.peers.get(id);if(p){scene.remove(p.m);this.peers.delete(id);this.hudN()}},
 nearest(e){let b=P,bd=Math.hypot(P.x-e.x,P.z-e.z);
  for(const p of this.peers.values()){const d=Math.hypot(p.x-e.x,p.z-e.z);if(d<bd){bd=d;b=p}}return b},
 follow(e,dt){
  if(e.tx!==undefined){const k=Math.min(1,12*dt);e.x+=(e.tx-e.x)*k;e.y+=(e.ty-e.y)*k;e.z+=(e.tz-e.z)*k;e.yaw=e.tyaw}
  e.m.position.set(e.x,e.y,e.z);e.m.rotation.y=e.yaw;
  e.mat.color.setHex(e.hurtT>0?0xffffff:ENEMY_STYLE[S.world].body)},
 clearFoes(){for(const e of enemies)scene.remove(e.m);enemies=[];foesLeft=0},
 recv(m){
  switch(m.t){
  case 'init':
   this.id=m.id;this.host=m.host;this.clearPeers();
   for(const p of m.players)this.addPeer(p);
   if(m.edits.length){for(const[x,y,z,id]of m.edits)sb(x,y,z,id);rebuildMeshes()}
   if(m.portal){this.clearFoes();updateFoes();if(portal&&!portal.active)openPortal()}
   this.hudN();break;
  case 'join':this.addPeer(m.p);break;
  case 'leave':this.delPeer(m.id);break;
  case 'host':this.host=(m.id===this.id);break;
  case 'p':{const p=this.peers.get(m.id);if(p){p.tx=m.x;p.ty=m.y;p.tz=m.z;p.tyaw=m.yaw}break}
  case 'blk':sb(m.x,m.y,m.z,m.id);rebuildMeshes();break;
  case 'en':{
   if(this.host)break;
   const seen=new Set();
   for(const[id,x,y,z,yaw,hp]of m.e){seen.add(id);const e=enemies.find(q=>q.id===id);
    if(e){e.tx=x;e.ty=y;e.tz=z;e.tyaw=yaw;e.hp=hp}}
   for(let i=enemies.length-1;i>=0;i--)if(!seen.has(enemies[i].id)){scene.remove(enemies[i].m);enemies.splice(i,1)}
   foesLeft=enemies.length;updateFoes();break}
  case 'hit':{
   const idx=enemies.findIndex(q=>q.id===m.id);if(idx<0)break;
   const e=enemies[idx],f=this.peers.get(m.from)||P;
   e.hp-=m.dmg;e.hurtT=.15;sfx.hitE();
   const dx=e.x-f.x,dz=e.z-f.z,d=Math.hypot(dx,dz)||1;
   e.vx=dx/d*7;e.vz=dz/d*7;e.vy=5;e.y+=.06;
   if(e.hp<=0)killEnemy(idx,true);break}
  case 'kill':{
   if(this.host)break;
   const idx=enemies.findIndex(q=>q.id===m.id);if(idx>=0){scene.remove(enemies[idx].m);enemies.splice(idx,1)}
   sfx.die();burst(m.x,m.y+.4,m.z,tileAvg[T[['grass_a_top','ember','purpur'][S.world]]],14);
   if(m.drop){const n=2+((Math.random()*3)|0);for(let i=0;i<n;i++)spawnOrb(m.x,m.y+.6,m.z,2+S.world*2+((S.isle/10)|0))}
   foesLeft=enemies.length;updateFoes();break}
  case 'portal':if(portal&&!portal.active){this.clearFoes();openPortal()}break;
  }},
 tick(dt){
  if(!this.on||S.title||S.busy)return;
  this.pT+=dt;if(this.pT>.05){this.pT=0;
   this.send({t:'p',x:+P.x.toFixed(2),y:+P.y.toFixed(2),z:+P.z.toFixed(2),yaw:+P.yaw.toFixed(2)})}
  if(this.host){this.enT+=dt;if(this.enT>.1){this.enT=0;
   this.send({t:'en',e:enemies.map(e=>[e.id,+e.x.toFixed(2),+e.y.toFixed(2),+e.z.toFixed(2),+e.yaw.toFixed(2),e.hp])})}}
  const k=Math.min(1,14*dt);
  for(const p of this.peers.values()){
   p.x+=(p.tx-p.x)*k;p.y+=(p.ty-p.y)*k;p.z+=(p.tz-p.z)*k;p.yaw+=(p.tyaw-p.yaw)*k;
   p.m.position.set(p.x,p.y,p.z);p.m.rotation.y=p.yaw}}
};

