// Islebound multiplayer: serves public/index.html + WebSocket rooms (one room per world:isle).
// Host = first player in a room; the host simulates enemies, everyone else follows snapshots.
const http = require('http'), fs = require('fs'), path = require('path');
const { WebSocketServer } = require('ws');
const PORT = process.env.PORT || 3000;
const MAX_PER_ROOM = 8, MAX_EDITS = 6000;

const patch = require('./patch');
let cached = null;
function getHtml(cb) {
  if (cached) return cb(null, cached);
  fs.readFile(path.join(__dirname, 'public', 'index.html'), 'utf8', (e, d) => {
    if (e) return cb(e);
    if (d.includes('const MP={')) { cached = d; return cb(null, d); }       // already patched
    const r = patch(d);
    if (r.fails.length) { console.error('[patch] FAILED, serving single-player:\n' + r.fails.join('\n')); cached = d; }
    else { console.log('[patch] multiplayer injected'); cached = r.html; }
    cb(null, cached);
  });
}
const server = http.createServer((req, res) => {
  if (req.url === '/health') { res.end('ok'); return; }
  getHtml((e, html) => {
    if (e) { res.writeHead(404); res.end('Put your game at public/index.html'); return; }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); res.end(html);
  });
});
const wss = new WebSocketServer({ server, maxPayload: 65536 });
const rooms = new Map();
let nextId = 1;
const num = v => typeof v === 'number' && isFinite(v);
const send = (ws, m) => { if (ws.readyState === 1) ws.send(JSON.stringify(m)); };
const bc = (room, m, except) => { for (const p of room.players.values()) if (p !== except) send(p, m); };

function leave(ws) {
  const room = ws.room; if (!room) return;
  room.players.delete(ws.id); ws.room = null;
  if (!room.players.size) { rooms.delete(room.key); return; }
  bc(room, { t: 'leave', id: ws.id });
  if (room.host === ws.id) { room.host = room.players.keys().next().value; bc(room, { t: 'host', id: room.host }); }
}

wss.on('connection', ws => {
  ws.id = nextId++; ws.alive = true; ws.room = null; ws.p = { x: 0, y: 0, z: 0, yaw: 0 }; ws.name = 'Wanderer';
  ws.on('pong', () => ws.alive = true);
  ws.on('close', () => leave(ws));
  ws.on('error', () => {});
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (!m || typeof m.t !== 'string') return;

    if (m.t === 'join') {
      if (!Number.isInteger(m.w) || !Number.isInteger(m.i) || m.w < 0 || m.w > 2 || m.i < 1 || m.i > 42) return;
      leave(ws);
      const key = m.w + ':' + m.i;
      let room = rooms.get(key);
      if (!room) { room = { key, players: new Map(), host: null, edits: new Map(), portal: false }; rooms.set(key, room); }
      if (room.players.size >= MAX_PER_ROOM) { send(ws, { t: 'full' }); return; }
      ws.name = String(m.name || 'Wanderer').slice(0, 14);
      room.players.set(ws.id, ws); ws.room = room;
      if (!room.host) room.host = ws.id;
      send(ws, { t: 'init', id: ws.id, host: room.host === ws.id, portal: room.portal,
        players: [...room.players.values()].filter(p => p !== ws).map(p => ({ id: p.id, name: p.name, ...p.p })),
        edits: [...room.edits.values()] });
      bc(room, { t: 'join', p: { id: ws.id, name: ws.name } }, ws);
      return;
    }
    const room = ws.room; if (!room) return;
    const isHost = room.host === ws.id;

    if (m.t === 'p') {
      if (![m.x, m.y, m.z, m.yaw].every(num)) return;
      ws.p = { x: m.x, y: m.y, z: m.z, yaw: m.yaw };
      bc(room, { t: 'p', id: ws.id, ...ws.p }, ws);
    } else if (m.t === 'blk') {
      if (![m.x, m.y, m.z, m.id].every(Number.isInteger)) return;
      if (m.x < 0 || m.x >= 48 || m.y < 0 || m.y >= 28 || m.z < 0 || m.z >= 48 || m.id < 0 || m.id > 40) return;
      if (room.edits.size < MAX_EDITS) room.edits.set(m.x + ',' + m.y + ',' + m.z, [m.x, m.y, m.z, m.id]);
      bc(room, { t: 'blk', x: m.x, y: m.y, z: m.z, id: m.id }, ws);
    } else if (m.t === 'hit') {                       // non-host -> host only
      if (isHost || !Number.isInteger(m.id) || !num(m.dmg)) return;
      const h = room.players.get(room.host); if (h) send(h, { t: 'hit', id: m.id, dmg: Math.min(10, m.dmg), from: ws.id });
    } else if (isHost && (m.t === 'en' || m.t === 'kill' || m.t === 'portal')) {  // host -> everyone else
      if (m.t === 'portal') room.portal = true;
      m.from = ws.id; bc(room, m, ws);
    }
  });
});

setInterval(() => { for (const ws of wss.clients) { if (!ws.alive) { ws.terminate(); continue; } ws.alive = false; ws.ping(); } }, 30000);
server.listen(PORT, () => console.log('Islebound listening on ' + PORT));
