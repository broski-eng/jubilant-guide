// Applies the multiplayer edits to the ORIGINAL Islebound index.html (string-exact, each anchor must match once).
const fs = require('fs'), path = require('path');
const MP = fs.readFileSync(path.join(__dirname, 'mp-client.js'), 'utf8');

const EDITS = [
  ['function spawnEnemy(rec){', 'function spawnEnemy(rec,id){'],
  ['enemies.push({m:g,mat:body,', 'enemies.push({id,m:g,mat:body,'],
  ['for(const r of cur.enemies)spawnEnemy(r);', 'cur.enemies.forEach((r,i)=>spawnEnemy(r,i));'],
  ['foes guard the portal`);', 'foes guard the portal`);MP.join();'],
  ["$('hud').classList.add('on');", "$('hud').classList.add('on');MP.connect();"],
  ['const e=enemies[i];e.hurtT-=dt;e.touchT-=dt;', 'const e=enemies[i];e.hurtT-=dt;e.touchT-=dt;\n  if(MP.on&&!MP.host){MP.follow(e,dt)}else{'],
  ['// contact damage', '}\n  // contact damage'],
  ['const dx=P.x-e.x,dz=P.z-e.z,d=Math.hypot(dx,dz);', 'const tg=MP.nearest(e),dx=tg.x-e.x,dz=tg.z-e.z,d=Math.hypot(dx,dz);'],
  ['if(e.y<-16){killEnemy(i,false);continue}', 'if(!(MP.on&&!MP.host)&&e.y<-16){killEnemy(i,false);continue}'],
  ['const dmg=1+Math.floor((S.lvl-1)/6);',
   "const dmg=1+Math.floor((S.lvl-1)/6);\n if(MP.on&&!MP.host){MP.send({t:'hit',id:e.id,dmg});sfx.hitE();e.hurtT=.15;floatText(e.x,e.y+1.2,e.z,'-'+dmg,'dmg');return}"],
  ['enemies.splice(idx,1);', "enemies.splice(idx,1);MP.send({t:'kill',id:e.id,x:e.x,y:e.y,z:e.z,drop});"],
  ['portal.active=true;sfx.portal();', "if(MP.host)MP.send({t:'portal'});portal.active=true;sfx.portal();"],
  ['sb(hit.x,hit.y,hit.z,0);rebuildMeshes();sfx.break();', "sb(hit.x,hit.y,hit.z,0);rebuildMeshes();sfx.break();MP.send({t:'blk',x:hit.x,y:hit.y,z:hit.z,id:0});"],
  ['sb(x,y,z,h.block);rebuildMeshes();sfx.place();', "sb(x,y,z,h.block);rebuildMeshes();sfx.place();MP.send({t:'blk',x,y,z,id:h.block});"],
  ['renderer.render(scene,camera);', "guard('mp',()=>MP.tick(dt));\n renderer.render(scene,camera);"],
];
const MARK = '/* ================= MAIN LOOP ================= */';

function patch(html) {
  const fails = [];
  for (const [a, b] of EDITS) {
    const n = html.split(a).length - 1;
    if (n !== 1) { fails.push(`"${a.slice(0, 50)}" matched ${n}x`); continue; }
    html = html.replace(a, () => b);
  }
  if (html.split(MARK).length - 1 !== 1) fails.push('MAIN LOOP marker not found');
  else html = html.replace(MARK, () => MP + MARK);
  return { html, fails };
}
module.exports = patch;

if (require.main === module) {   // optional: node patch.js in.html out.html
  const r = patch(fs.readFileSync(process.argv[2], 'utf8'));
  if (r.fails.length) { console.error('FAILED:\n' + r.fails.join('\n')); process.exit(1); }
  fs.writeFileSync(process.argv[3], r.html); console.log('patched ->', process.argv[3]);
}
